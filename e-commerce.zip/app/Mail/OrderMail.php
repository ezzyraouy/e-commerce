<?php 
namespace App\Mail;

use App\Models\Order;
use Illuminate\Mail\Mailable;
use Barryvdh\DomPDF\Facade\Pdf;

class OrderMail extends Mailable
{
    public $order;

    public function __construct(Order $order)
    {
        $this->order = $order;
    }

    public function build()
    {
        // Generate the PDF content
        $pdfContent = $this->generatePdf();

        // Attach the PDF to the email
        return $this->subject('Order Invoice')
                    ->view('emails.order') // Email body
                    ->with(['order' => $this->order]) // Pass order details to email view
                    ->attachData($pdfContent, 'invoice.pdf', [
                        'mime' => 'application/pdf',
                    ]);
    }

    private function generatePdf()
    {
        // Generate a PDF using a Blade template
        $pdf = Pdf::loadView('pdf.invoice', [
            'order' => $this->order, // Pass the order data to the template
        ]);

        return $pdf->output(); // Return PDF file content
    }
}
