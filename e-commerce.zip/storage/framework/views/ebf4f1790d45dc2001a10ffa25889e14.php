<?php $__env->startComponent('mail::message'); ?>
    Bonjour
    Vous avez un nouveau message de: <strong><?php echo e($details['name']); ?></strong> <br>
    <strong>Nom et Prenom:</strong> <?php echo e($details['name']); ?> <br>
    <?php if(!empty($details['email'])): ?>
        <strong>Email:</strong> <?php echo e($details['email']); ?> <br>
    <?php endif; ?>
    <?php if(!empty($details['tele'])): ?>
        <strong>Télephone:</strong> <?php echo e($details['tele']); ?> <br>
    <?php endif; ?>
    <?php if(!empty($details['message'])): ?>
           <strong>Message:</strong> <?php echo e($details['message']); ?><br><br>
    <?php endif; ?>
 
    Cordialement,
<?php echo $__env->renderComponent(); ?>

<?php /**PATH C:\xampp\htdocs\e-commerce\resources\views/emails/contact.blade.php ENDPATH**/ ?>