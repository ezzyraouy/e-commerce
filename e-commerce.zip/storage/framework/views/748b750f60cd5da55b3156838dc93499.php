
<!-- main-content-wrap -->
<?php $__env->startSection('content'); ?>
<div class="main-content-inner">
    <!-- main-content-wrap -->
    <div class="main-content-wrap">
     
    </div>
    <!-- /main-content-wrap -->
</div>
<?php $__env->stopSection(); ?>
<!-- /main-content-wrap -->
<?php echo $__env->make('back-office.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\e-commerce\resources\views/back-office/index.blade.php ENDPATH**/ ?>