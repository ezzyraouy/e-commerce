
<?php $__env->startSection('content'); ?>
<div class="main-content-inner">
    <!-- main-content-wrap -->
    <div class="main-content-wrap">
        <div class="flex items-center flex-wrap justify-between gap20 mb-30">
            <h3>Edit unit</h3>
            <ul class="breadcrumbs flex items-center flex-wrap justify-start gap10">
                <li>
                    <a href="index.html">
                        <div class="text-tiny">Dashboard</div>
                    </a>
                </li>
                <li>
                    <i class="icon-chevron-right"></i>
                </li>
                <li>
                    <a href="#">
                        <div class="text-tiny">unit</div>
                    </a>
                </li>
                <li>
                    <i class="icon-chevron-right"></i>
                </li>
                <li>
                    <div class="text-tiny">Edit unit</div>
                </li>
            </ul>
        </div>
        <!-- form-edit-product -->
        <form class="form-edit-product" action="<?php echo e(route('units.update',$unit->id)); ?>" method="POST" enctype="multipart/form-data">
           <?php echo method_field('PUT'); ?>
           <?php echo $__env->make('back-office.units.form',[$units,$unit], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </form>
        <!-- /form-edit-product -->
    </div>
    <!-- /main-content-wrap -->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('back-office.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\e-commerce\resources\views/back-office/units/edit.blade.php ENDPATH**/ ?>