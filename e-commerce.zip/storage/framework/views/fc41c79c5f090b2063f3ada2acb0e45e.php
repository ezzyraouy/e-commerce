
Hello,

You have received a new order with the following details:

<table style="width: 100%; border-collapse: collapse; margin: 20px 0; border: 1px solid #ddd;">
    <thead>
        <tr>
            <th style="border: 1px solid #ddd; padding: 8px; text-align: left; background-color: #f8f9fa;">Field</th>
            <th style="border: 1px solid #ddd; padding: 8px; text-align: left; background-color: #f8f9fa;">Details</th>
        </tr>
    </thead>
    <tbody>
        <!-- Order Details -->
        <tr>
            <td style="border: 1px solid #ddd; padding: 8px; font-weight: bold;">Order ID</td>
            <td style="border: 1px solid #ddd; padding: 8px;"><?php echo e($order->id); ?></td>
        </tr>
        
        <!-- Order Products -->
        <tr>
            <td style="border: 1px solid #ddd; padding: 8px; font-weight: bold;">Order Products</td>
            <td style="border: 1px solid #ddd; padding: 8px;">
                <ul style="padding-left: 20px; margin: 0;">
                    <?php $__currentLoopData = $order->OrderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><strong><?php echo e($item->product->name); ?></strong> (Quantity: <?php echo e($item->quantity); ?>)</li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </td>
        </tr>
        
        <!-- Customer Details -->
        <tr>
            <td style="border: 1px solid #ddd; padding: 8px; font-weight: bold;">Customer Name</td>
            <td style="border: 1px solid #ddd; padding: 8px;"><?php echo e($order->user->name); ?></td>
        </tr>
        <tr>
            <td style="border: 1px solid #ddd; padding: 8px; font-weight: bold;">Phone</td>
            <td style="border: 1px solid #ddd; padding: 8px;"><?php echo e($order->user->phone); ?></td>
        </tr>
        <tr>
            <td style="border: 1px solid #ddd; padding: 8px; font-weight: bold;">Email</td>
            <td style="border: 1px solid #ddd; padding: 8px;"><?php echo e($order->user->email); ?></td>
        </tr>
    </tbody>
</table>

<?php /**PATH C:\xampp\htdocs\e-commerce\resources\views/emails/order.blade.php ENDPATH**/ ?>