@extends('back-office.layouts.master')
<!-- main-content-wrap -->
@section('content')
<div class="main-content-inner">
    <!-- main-content-wrap -->
    <div class="main-content-wrap">
     
    </div>
    <!-- /main-content-wrap -->
</div>
@endsection
<!-- /main-content-wrap -->