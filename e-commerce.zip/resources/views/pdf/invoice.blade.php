<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Facture</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        .container {
            width: 100%;
            margin: 0 auto;
            padding: 20px;
        }
        .header, .footer {
            text-align: center;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        .totals {
            text-align: right;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h2>Facture Fiscale</h2>
            <p>Nom de l'entreprise : {{ $order->company_name }}</p>
            <p>Numéro fiscal : {{ $order->tax_number }}</p>
        </div>

        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Nom du produit</th>
                    <th>Unité</th>
                    <th>Quantité</th>
                    <th>Prix (SAR)</th>
                    <th>Remise (SAR)</th>
                    <th>Taxe (15%)</th>
                    <th>Total (SAR)</th>
                </tr>
            </thead>
            <tbody>
                @foreach($order->OrderItems as $index => $item)
                    @php
                        $price = $item->UnitProduct->price;
                        $discount = $item->discount ?? 0;
                        $subtotal = ($price - $discount) * $item->quantity;
                        $tax = $subtotal * 0.15;
                        $total = $subtotal + $tax;
                    @endphp
                    <tr>
                        <td>{{ $index + 1 }}</td>
                        <td>{{ $item->product->name }}</td>
                        <td>{{ $item->UnitProduct->unit->name }}</td>
                        <td>{{ $item->quantity }}</td>
                        <td>{{ number_format($price, 2) }}</td>
                        <td>{{ number_format($discount, 2) }}</td>
                        <td>{{ number_format($tax, 2) }}</td>
                        <td>{{ number_format($total, 2) }}</td>
                    </tr>
                @endforeach
            </tbody>
        </table>

        <div class="totals">
            <p>Total Général : {{ number_format($order->OrderItems->sum(function($item) {
                $price = $item->UnitProduct->price;
                $discount = $item->discount ?? 0;
                $subtotal = ($price - $discount) * $item->quantity;
                $tax = $subtotal * 0.15;
                return $subtotal + $tax;
            }), 2) }} SAR</p>
        </div>

        <div class="footer">
            <p>Merci pour votre confiance !</p>
        </div>
    </div>
</body>
</html>
